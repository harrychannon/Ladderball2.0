﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManage : MonoBehaviour
{

    public void LoadS(string Load) //load scene based on what the string Load is called.
    {
        SceneManager.LoadScene(Load);
    }

    public void CloseGame() //close app.
    {
        Application.Quit();
    }
}
