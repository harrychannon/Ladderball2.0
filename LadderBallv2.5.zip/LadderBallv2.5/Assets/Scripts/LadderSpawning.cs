﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LadderSpawning : MonoBehaviour
{

    public GameObject StaticLadderPrefab;
    public GameObject MovingLadderPrefab;
    public GameObject AddTimeCollectable;

    public GameObject PlayerBall;

    private float CurrentYCoord;
    private float LadderChangeDistance = 125.0f;
    private float LadderXPosition;

    public int QuantityOfPoolStaticLadders;
    public int QuantityOfPoolMovingLadders;

    List<GameObject> StaticLadders;
    List<GameObject> MovingLadders;

    // Use this for initialization
    void Start()
    {
        CurrentYCoord = 5.0f;

        StaticLadders = new List<GameObject>();
        MovingLadders = new List<GameObject>();


        for (int i = 0; i < QuantityOfPoolStaticLadders; i++)
        {
            GameObject obj = (GameObject)Instantiate(StaticLadderPrefab);
            obj.SetActive(false);
            StaticLadders.Add(obj);
        }

        for (int i = 0; i < QuantityOfPoolMovingLadders; i++)
        {
            GameObject obj = (GameObject)Instantiate(MovingLadderPrefab);
            obj.SetActive(false);
            MovingLadders.Add(obj);
        }

    }

    // Update is called once per frame
    void Update()
    {
        CheckPlayerHeight();
    }

    void CheckPlayerHeight()
    {
        if (CurrentYCoord < LadderChangeDistance)
        {
            for (int i = 0; i < StaticLadders.Count; i++)
            {
                if (Vector3.Distance(PlayerBall.transform.position, new Vector3(0.0f, CurrentYCoord, 0.0f)) < 15.0f)
                {
                    if (!StaticLadders[i].activeInHierarchy)
                    {
                        float RandomNumberGen;

                        StaticLadders[i].SetActive(true);

                        RandomNumberGen = Random.value;
                        if (RandomNumberGen <= 0.3f)
                            LadderXPosition = -1.0f;
                        else if ((RandomNumberGen > 0.3f) && (RandomNumberGen <= 0.6f))
                            LadderXPosition = 1.0f;
                        else if (RandomNumberGen > 0.6f)
                            LadderXPosition = 0.0f;

                        StaticLadders[i].transform.position = new Vector3(LadderXPosition, CurrentYCoord, 0.0f);
                        StaticLadders[i].transform.eulerAngles = new Vector3(0.0f, 90.0f, 0.0f);
                        if (CurrentYCoord % 20 == 0)
                        {
                            Instantiate(AddTimeCollectable, new Vector3(LadderXPosition, CurrentYCoord + 2 , 0.0f), Quaternion.identity);
                        }
                        CurrentYCoord += 5.0f;
                    }
                    else if ((StaticLadders[i].activeInHierarchy) && (Vector3.Distance(PlayerBall.transform.position, StaticLadders[i].transform.position) > 30.0f))
                    {
                        StaticLadders[i].SetActive(false);
                    }
                }
            }
        }

        if (CurrentYCoord >= LadderChangeDistance)
        {
            for (int i = 0; i < MovingLadders.Count; i++)
            {
                if (Vector3.Distance(PlayerBall.transform.position, new Vector3(0.0f, CurrentYCoord, 0.0f)) < 15.0f)
                {
                    if (!MovingLadders[i].activeInHierarchy)
                    {
                        float RandomNumberGen;

                        MovingLadders[i].SetActive(true);

                        RandomNumberGen = Random.value;
                        if (RandomNumberGen <= 0.3f)
                            LadderXPosition = -0.8f;
                        else if ((RandomNumberGen > 0.3f) && (RandomNumberGen <= 0.6f))
                            LadderXPosition = 0.8f;
                        else if (RandomNumberGen > 0.6f)
                            LadderXPosition = 0.0f;

                        MovingLadders[i].transform.position = new Vector3(LadderXPosition, CurrentYCoord, 0.0f);
                        MovingLadders[i].transform.eulerAngles = new Vector3(0.0f, 90.0f, 0.0f);
                        if (CurrentYCoord % 20 == 0)
                        {
                            Instantiate(AddTimeCollectable, new Vector3(LadderXPosition, CurrentYCoord + 2, 0.0f), Quaternion.identity);
                        }
                        CurrentYCoord += 5.0f;
                    }
                    else if ((MovingLadders[i].activeInHierarchy) && (Vector3.Distance(PlayerBall.transform.position, MovingLadders[i].transform.position) > 30.0f))
                    {
                        MovingLadders[i].SetActive(false);
                    }
                }
            }
        }
    }
}
