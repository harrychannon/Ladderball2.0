﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimeController : MonoBehaviour {

    public float TimeRemaining;

    public Text UITXTTimeRemaining;
    public GameObject cvsMainGameUI;
    public GameObject cvsGameOverUI;

    public GameObject PlayerBall;

	// Use this for initialization
	void Start ()
    {
        TimeRemaining = 30.0f;
        cvsMainGameUI.SetActive(true);
        cvsGameOverUI.SetActive(false);
    }
	
	// Update is called once per frame
	void Update ()
    {
        TimerCountdown();
	}

    void TimerCountdown()
    {
        TimeRemaining -= Time.deltaTime;
        UITXTTimeRemaining.text = TimeRemaining.ToString("00");
        

        if (TimeRemaining <= 0)
        {
            TimeRemaining = 0.0f;
            PlayerBall.GetComponent<BallMovement>().IsGameOver = true;
            cvsMainGameUI.SetActive(false);
            cvsGameOverUI.SetActive(true);
        }
    }
}
