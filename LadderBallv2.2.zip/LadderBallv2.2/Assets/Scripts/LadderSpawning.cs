﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LadderSpawning : MonoBehaviour
{

    public GameObject StaticLadderPrefab;
    public GameObject MovingLadderPrefab;

    public GameObject PlayerBall;

    private float CurrentYCoord;

    public int QuantityOfPoolStaticLadders;
    public int QuantityOfPoolMovingLadders;

    List<GameObject> StaticLadders;
    List<GameObject> MovingLadders;

    // Use this for initialization
    void Start()
    {
        CurrentYCoord = 0.0f;

        StaticLadders = new List<GameObject>();
        MovingLadders = new List<GameObject>();


        for (int i = 0; i < QuantityOfPoolStaticLadders; i++)
        {
            GameObject obj = (GameObject)Instantiate(StaticLadderPrefab);
            obj.SetActive(false);
            StaticLadders.Add(obj);
        }

        for (int i = 0; i < QuantityOfPoolMovingLadders; i++)
        {
            GameObject obj = (GameObject)Instantiate(MovingLadderPrefab);
            obj.SetActive(false);
            MovingLadders.Add(obj);
        }

    }

    // Update is called once per frame
    void Update()
    {
        CheckPlayerHeight();
    }

    void CheckPlayerHeight()
    {
        if ((CurrentYCoord - PlayerBall.transform.position.y <= 5.0f) && (CurrentYCoord < 25.0f))
        {
            //Go through the static ladder list and check for any that aren't active yet and spawn them in at a CurrentYCoord, then increase CurrentYCoord by 5.0f
            for (int i = 0; i < StaticLadders.Count; i++)
            {
                if (!StaticLadders[i].activeInHierarchy)
                {
                    StaticLadders[i].SetActive(true);
                    //StaticLadders[i].transform.position = transform.position;
                    //StaticLadders[i].transform.rotation = transform.rotation;
                }
            }
        }

        if ((CurrentYCoord - PlayerBall.transform.position.y <= 10.0f) && (CurrentYCoord > 25.0f))
        {
            //Go through and check for moving ladders that haven't been spawned in, spawn them and set position to CurrentYCoord, then increase CurrentYCoord by 5.0f
        }
    }
}
