﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingLadder : MonoBehaviour {

    public bool IsMovingLeft = true;
    public bool IsMovingRight = false;

    private float MovementSpeed;

    void Update()
    {
        if (IsMovingLeft == true)
        {
            MoveLeft();
        }

        if (IsMovingRight == true)
        {
            MoveRight();
        }
    }


    private void OnCollisionEnter(Collision Barrier)
    {
        if (Barrier.gameObject.tag == "Barrier")
        {
            if (IsMovingLeft == true)
            {
                IsMovingLeft = false;
                IsMovingRight = true;
            }
            else if (IsMovingRight == true)
            {
                IsMovingRight = false;
                IsMovingLeft = true;
            }
        }
    }

    void MoveLeft()
    {
        MovementSpeed = Random.Range(1.0f, 4.0f);
        transform.Translate(Vector3.forward * MovementSpeed * Time.deltaTime);
    }

    void MoveRight()
    {
        MovementSpeed = Random.Range(1.0f, 4.0f);
        transform.Translate(Vector3.back * MovementSpeed * Time.deltaTime);
    }
}
