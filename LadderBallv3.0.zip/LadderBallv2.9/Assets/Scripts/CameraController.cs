﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

    public GameObject PlayerBall;
    
	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        //This just gets the position of the player and follows it Y value only so that the player is always on the screen
        transform.position = Vector3.Slerp(transform.position, new Vector3(0.0f, PlayerBall.transform.position.y + 3, -10.0f), 2.0f);
	}
}
