﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingLadder : MonoBehaviour {

    public bool IsMovingLeft = true;
    public bool IsMovingRight = false;

    private float MovementSpeed;

    void Update()
    {
        //If the ladder is moving left then call the move left funtion
        if (IsMovingLeft == true)
        {
            MoveLeft();
        }

        //If the ladder is moving right then call the move right function
        if (IsMovingRight == true)
        {
            MoveRight();
        }
    }


    private void OnCollisionEnter(Collision Barrier)
    {
        //When the ladder collides with the barrier
        if (Barrier.gameObject.tag == "Barrier")
        {
            //If it was moving left, the begin moving it to the right
            if (IsMovingLeft == true)
            {
                IsMovingLeft = false;
                IsMovingRight = true;
            }
            //If it was moving right, the behin moving it to the left
            else if (IsMovingRight == true)
            {
                IsMovingRight = false;
                IsMovingLeft = true;
            }
        }
    }

    void MoveLeft()
    {
        //This calculates a random speed for the ladder to move at
        MovementSpeed = Random.Range(1.0f, 4.0f);
        //This moves the ladder at a constant rate
        transform.Translate(Vector3.forward * MovementSpeed * Time.deltaTime);
    }

    void MoveRight()
    {
        //This calculates a random speed for the ladder to move at
        MovementSpeed = Random.Range(1.0f, 4.0f);
        //This moves the ladder at a constant rate
        transform.Translate(Vector3.back * MovementSpeed * Time.deltaTime);
    }
}
