﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseController : MonoBehaviour {

    public bool IsGamePaused;

    public GameObject cvsGamePausedUI;
    public GameObject cvsMainGameUI;

    // Use this for initialization
    void Start ()
    {
        //Bool to check if the game is paused or not
        IsGamePaused = false;
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public void PauseButtonPress()
    {
        //When the button is pressed and the bool is false, then pause the game
        if (IsGamePaused == false)
        {
            IsGamePaused = true;
            cvsMainGameUI.SetActive(false);
            cvsGamePausedUI.SetActive(true);
            Time.timeScale = 0;
        }
        //If the button is pressed and the game is paused, then unpause the game
        else if (IsGamePaused == true)
        {
            IsGamePaused = false;
            cvsMainGameUI.SetActive(true);
            cvsGamePausedUI.SetActive(false);
            Time.timeScale = 1;
        }
    }
}
