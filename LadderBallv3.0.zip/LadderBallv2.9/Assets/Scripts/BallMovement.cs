﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMovement : MonoBehaviour {

    private Vector3 InitialTouchPos;
    private Vector3 LastTouchPos;

    private Vector3 MouseInitialTouchPos;
    private Vector3 MouseLastTouchPos;

    private Vector3 BallMovementVector;

    public GameObject GameManager;

    public bool IsGameOver;
    public bool HasGameStarted;

    // Use this for initialization
    void Start ()
    {
        //Setting the bools to false at the start makes sure everything runs correctly
        HasGameStarted = false;
        IsGameOver = false;
	}
	
	// Update is called once per frame
	void Update ()
    {
        //If the game isn't over, then call the function that controls player movement, otherwise if the game is over, don't call it so that the player can't move anymore
        if (IsGameOver == false)
        {
            DetectPlayerTouch();
        }

        //This checks to see if the player has moved or not, if they have then start the countdown, otherwise don't
        if (HasGameStarted == true)
        {
            GameManager.GetComponent<TimeController>().TimerCountdown();
        }
    }

    void DetectPlayerTouch()
    {
        //If the user has a single finger on the screen
        if (Input.touchCount == 1)
        {
            Touch GettingPlayerTouch = Input.GetTouch(0);

            //When the finger first touches the screen, get the position of the finger on the screen
            if (GettingPlayerTouch.phase == TouchPhase.Began)
            {
                InitialTouchPos = GettingPlayerTouch.position;
                LastTouchPos = GettingPlayerTouch.position;
            }

            //When the finger moves, update the last known position
            else if (GettingPlayerTouch.phase == TouchPhase.Moved)
            {
                LastTouchPos = GettingPlayerTouch.position;
            }

            //When the finger is taken off the screen
            else if (GettingPlayerTouch.phase == TouchPhase.Ended)
            {
                //The game has begun as the user has begun to move
                HasGameStarted = true;

                //Update the last known position of the finger to the final place
                LastTouchPos = GettingPlayerTouch.position;

                //Calculate the direction the player wants to move the ball by subtracting the last known touch position from the initial touch position (Y is absolute value so the player keeps moving up)
                BallMovementVector.x = (InitialTouchPos.x - LastTouchPos.x) * 1.4f;
                BallMovementVector.y = Mathf.Abs(InitialTouchPos.y - LastTouchPos.y);

                //Add a force to the player using the direction calculated
                GetComponent<Rigidbody>().AddForce(BallMovementVector.x, BallMovementVector.y, 0.0f);
            }
        }
    }

    void OnCollisionEnter(Collision CollidedObject)
    {
        //If the player hits an object with the tag AddTime
        if (CollidedObject.gameObject.tag == "AddTime")
        {
            //Destroys the gameobjecy (In this case, it destroys the coin)
            Destroy(CollidedObject.gameObject);
            //Add 5 seconds to the timer as a reward
            GameManager.GetComponent<TimeController>().TimeRemaining += 5.0f;
        }
    }



    //BELOW ARE CONTROLS INTENDED FOR DEBUGGING IN EDITOR

    //MOUSE CONTROLS FOR TESTING
    /*void OnMouseDown()
    {
        if (IsGameOver == false)
        {
            MouseInitialTouchPos = Input.mousePosition;
            MouseLastTouchPos = Input.mousePosition;
        }
    }

    //MOUSE CONTROLS FOR TESTING
    void OnMouseUp()
    {
        if (IsGameOver == false)
        {
            HasGameStarted = true;

            MouseLastTouchPos = Input.mousePosition;

            BallMovementVector.x = (MouseInitialTouchPos.x - MouseLastTouchPos.x);
            BallMovementVector.y = Mathf.Abs(MouseInitialTouchPos.y - MouseLastTouchPos.y);

            GetComponent<Rigidbody>().AddForce(BallMovementVector.x, BallMovementVector.y, 0.0f);
        }
    }*/
}
