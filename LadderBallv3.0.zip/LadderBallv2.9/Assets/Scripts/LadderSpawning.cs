﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LadderSpawning : MonoBehaviour
{

    public GameObject StaticLadderPrefab;
    public GameObject MovingLadderPrefab;
    public GameObject AddTimeCollectable;

    public GameObject PlayerBall;

    private float CurrentYCoord;
    private float LadderChangeDistance = 125.0f;
    private float LadderXPosition;

    public int QuantityOfPoolStaticLadders;
    public int QuantityOfPoolMovingLadders;

    List<GameObject> StaticLadders;
    List<GameObject> MovingLadders;

    // Use this for initialization
    void Start()
    {
        //This initialises the Y coord which I will be using to spawn in objects from the pool at
        CurrentYCoord = 5.0f;

        //Making the object pool list for both types of ladders
        StaticLadders = new List<GameObject>();
        MovingLadders = new List<GameObject>();

        //Filling the pools with objects
        for (int i = 0; i < QuantityOfPoolStaticLadders; i++)
        {
            GameObject obj = (GameObject)Instantiate(StaticLadderPrefab);
            obj.SetActive(false);
            StaticLadders.Add(obj);
        }

        for (int i = 0; i < QuantityOfPoolMovingLadders; i++)
        {
            GameObject obj = (GameObject)Instantiate(MovingLadderPrefab);
            obj.SetActive(false);
            MovingLadders.Add(obj);
        }

    }

    // Update is called once per frame
    void Update()
    {
        //Calls this function every frame as I need to spawn in ladders if the player gets too close
        CheckPlayerHeight();
    }

    void CheckPlayerHeight()
    {
        //So if the variable is lower than a set value, it spawns in the static ladders
        if (CurrentYCoord < LadderChangeDistance)
        {
            //Going through the object pool
            for (int i = 0; i < StaticLadders.Count; i++)
            {
                //If the distance between the ball and the position where the ladders would spawn is less than a certain value
                if (Vector3.Distance(PlayerBall.transform.position, new Vector3(0.0f, CurrentYCoord, 0.0f)) < 15.0f)
                {
                    //Check if the ladder game object is not active
                    if (!StaticLadders[i].activeInHierarchy)
                    {
                        float RandomNumberGen;

                        //Set the ladder to active
                        StaticLadders[i].SetActive(true);

                        //This gets a random x position from 3 set values to spawn at
                        RandomNumberGen = Random.value;
                        if (RandomNumberGen <= 0.3f)
                            LadderXPosition = -1.0f;
                        else if ((RandomNumberGen > 0.3f) && (RandomNumberGen <= 0.6f))
                            LadderXPosition = 1.0f;
                        else if (RandomNumberGen > 0.6f)
                            LadderXPosition = 0.0f;

                        //Sets the position of the ladder at the new vector3 including the calculated x position and the Ycoord
                        StaticLadders[i].transform.position = new Vector3(LadderXPosition, CurrentYCoord, 0.0f);
                        //Rotate the ladder by 90 to make it look right
                        StaticLadders[i].transform.eulerAngles = new Vector3(0.0f, 90.0f, 0.0f);
                        //This spawns in a coin every 4 ladders so that the player can add to their time
                        if (CurrentYCoord % 20 == 0)
                        {
                            //It instantiates a coin at the same x position as the ladder, and slightly higher in the y position
                            Instantiate(AddTimeCollectable, new Vector3(LadderXPosition, CurrentYCoord + 2 , 0.0f), Quaternion.identity);
                        }
                        //Increase the Y coord for the next value
                        CurrentYCoord += 5.0f;
                    }
                    //This checks to see if the ladder is active and if it is and the distance between it and the player ball is bigger than a certain distance, it deactivates
                    else if ((StaticLadders[i].activeInHierarchy) && (Vector3.Distance(PlayerBall.transform.position, StaticLadders[i].transform.position) > 30.0f))
                    {
                        StaticLadders[i].SetActive(false);
                    }
                }
            }
        }


        //The exact same as above, but instead for the moving ladders
        if (CurrentYCoord >= LadderChangeDistance)
        {
            for (int i = 0; i < MovingLadders.Count; i++)
            {
                if (Vector3.Distance(PlayerBall.transform.position, new Vector3(0.0f, CurrentYCoord, 0.0f)) < 15.0f)
                {
                    if (!MovingLadders[i].activeInHierarchy)
                    {
                        float RandomNumberGen;

                        MovingLadders[i].SetActive(true);

                        RandomNumberGen = Random.value;
                        if (RandomNumberGen <= 0.3f)
                            LadderXPosition = -0.8f;
                        else if ((RandomNumberGen > 0.3f) && (RandomNumberGen <= 0.6f))
                            LadderXPosition = 0.8f;
                        else if (RandomNumberGen > 0.6f)
                            LadderXPosition = 0.0f;

                        MovingLadders[i].transform.position = new Vector3(LadderXPosition, CurrentYCoord, 0.0f);
                        MovingLadders[i].transform.eulerAngles = new Vector3(0.0f, 90.0f, 0.0f);
                        if (CurrentYCoord % 20 == 0)
                        {
                            Instantiate(AddTimeCollectable, new Vector3(LadderXPosition, CurrentYCoord + 2, 0.0f), Quaternion.identity);
                        }
                        CurrentYCoord += 5.0f;
                    }
                    else if ((MovingLadders[i].activeInHierarchy) && (Vector3.Distance(PlayerBall.transform.position, MovingLadders[i].transform.position) > 30.0f))
                    {
                        MovingLadders[i].SetActive(false);
                    }
                }
            }
        }
    }
}
