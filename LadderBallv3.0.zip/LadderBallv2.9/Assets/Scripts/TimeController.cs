﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
public class TimeController : MonoBehaviour {

    public float TimeRemaining;
    public float PlayerScore;
    public int score;
    public string username;
    public Text UITXTTimeRemaining;
    public Text UITXTDistanceTravelled;
    public GameObject cvsMainGameUI;
    public GameObject cvsGameOverUI;

    public GameObject PlayerBall;

    private bool FinalPositionGotten;

	// Use this for initialization
	void Start ()
    {
        //This bool checks if the game has calculated the final position of the player
        FinalPositionGotten = false;
        //This is the timer starting at 30 seconds
        TimeRemaining = 30.0f;
        //This updates the UI with the current time remaining
        UITXTTimeRemaining.text = TimeRemaining.ToString("00");
        //This just makes sure that the correct canvas is shows on screen
        cvsMainGameUI.SetActive(true);
        cvsGameOverUI.SetActive(false);
    }
	
	// Update is called once per frame
	void Update ()
    {

	}

    public void TimerCountdown()
    {
        //This decreases the time remaining by deltatime, which is real time
        TimeRemaining -= Time.deltaTime;
        //Update the UI element to display the correct time left
        UITXTTimeRemaining.text = TimeRemaining.ToString("00");
        
        //If the time left is 0
        if (TimeRemaining <= 0)
        {
            //Set the time left to 0 so it doesn't keep going into negatives
            TimeRemaining = 0.0f;
            //Set the game over bool to be true to the player can't move anymore
            PlayerBall.GetComponent<BallMovement>().IsGameOver = true;
            //Make sure that the correct cavases are showing
            cvsMainGameUI.SetActive(false);
            cvsGameOverUI.SetActive(true);
            //If the final position hasn't been calculated
            if (FinalPositionGotten == false)
            {
                //Get the Y position of the player
                PlayerScore = PlayerBall.transform.position.y;
                //Update the UI text to that position, going to 2 decomal places
                UITXTDistanceTravelled.text = PlayerScore.ToString("00.00") + " Metres";
                //Say that the final position has been calculated
                FinalPositionGotten = true;
                
            }
            
          //  username = "testing score";

            
            
           // username = GUI.TextField(new Rect(0, -300, 800, 150), username, 12);
            
          //  score = Convert.ToInt32(PlayerScore);
         //   Highscores.AddNewHighscore(username, score);

        }
    }
    public void GetInput(string guess)
    {
        Debug.Log("You Entered " + guess);
        username = guess;
        score = Convert.ToInt32(PlayerScore);
        Highscores.AddNewHighscore(username, score);
    }
}
