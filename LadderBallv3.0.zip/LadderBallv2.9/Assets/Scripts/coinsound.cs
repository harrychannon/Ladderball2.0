﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coinsound : MonoBehaviour {
    AudioSource Coin;
    bool play;
    bool toggle;

	// Use this for initialization
	void Start () {
        Coin = GetComponent<AudioSource>();
	}
    void OnCollisionEnter(Collision CollidedObject)
    {
        if (CollidedObject.gameObject.tag == "AddTime")
        {
            Coin.Play();
            
        }
    }
    // Update is called once per frame
    void Update () {
		
	}
}
